package com.zzyy.study.day075;

import java.util.concurrent.TimeUnit;

/**
 * @auther zzyy
 * @create 2020-07-05 18:04
 */
public class DeadLockDemo
{
    static Object objectLockA = new Object();
    static Object objectLockB = new Object();

    public static void main(String[] args)
    {
        new Thread(() -> {
            synchronized (objectLockA)
            {
                System.out.println(Thread.currentThread().getName()+"\t"+"---自己持有A锁，希望获得B锁");
                try { TimeUnit.SECONDS.sleep(1); } catch (InterruptedException e) { e.printStackTrace(); }
                synchronized (objectLockB)
                {
                    System.out.println(Thread.currentThread().getName()+"\t"+"---成功获得B锁");
                }
            }
        },"A").start();

        new Thread(() -> {
            synchronized (objectLockB)
            {
                System.out.println(Thread.currentThread().getName()+"\t"+"---自己持有B锁，希望获得A锁");
                try { TimeUnit.SECONDS.sleep(1); } catch (InterruptedException e) { e.printStackTrace(); }
                synchronized (objectLockA)
                {
                    System.out.println(Thread.currentThread().getName()+"\t"+"---成功获得A锁");
                }
            }
        },"B").start();

    }
}
