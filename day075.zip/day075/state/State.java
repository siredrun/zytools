package com.zzyy.study.day075.state;

/**
 * @auther zzyy
 * @create 2020-07-03 20:55
 *
 *     一句话：状态--->行为
 */
public interface State
{
    void handle();

}
