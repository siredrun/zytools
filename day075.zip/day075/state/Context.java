package com.zzyy.study.day075.state;

/**
 * @auther zzyy
 * @create 2020-07-03 20:55
 */
public class Context
{
    private State state;

    public Context() {}

    public Context(State state) {
        this.state = state;
    }

    public void setState(State state)
    {
        System.out.println("订单信息已更新！");
        this.state = state;
        this.state.handle();
        System.out.println();
    }
}
