package com.zzyy.study.day075.state;

/**
 * @auther zzyy
 * @create 2020-07-03 20:57
 */
public class Payed implements  State {

    @Override
    public void handle() {
        System.out.println("您已付款！");
    }
}
