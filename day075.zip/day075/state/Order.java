package com.zzyy.study.day075.state;

/**
 * @auther zzyy
 * @create 2020-07-04 20:36
 */
public class Order
{
    public  static  String getStateName (int status)
    {

        String stateName = "" ;

        if (status == 1) {
            stateName = "已下单";
        } else if (status == 2) {
            stateName = "已付款";
        } else if (status == 3) {
            stateName = "已发货";
        } else if (status == 4) {
            stateName = "送货中";
        } else if (status == 5) {
            stateName = "确认收货";
        }
        return stateName;
    }
}
