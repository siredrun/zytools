package com.zzyy.study.day075.state;

/**
 * @auther zzyy
 * @create 2020-07-04 20:37
 */
public class Client
{
    public static void main(String[] args)
    {
        //before 关于订单状态的事情，大家有没有这样判断过
        System.out.println("=============以前的传统方式");
        String stateName = Order.getStateName(1);
        System.out.println(stateName);

        System.out.println();




        //after
        System.out.println("=========下面是用了state设计模式");
        Context context = new Context();

        context.setState(new Booked());
        context.setState(new Payed());
        /*context.setState(new Sended());
        context.setState(new InWay());
        context.setState(new Recieved());*/
    }
}
