package com.zzyy.study.entities;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.stereotype.Component;

/**
 * @auther zzyy
 * @create 2020-09-13 10:06
 */
@AllArgsConstructor
@Data
@NoArgsConstructor
@Component
public class Car
{
    private int id = 5;
    private String carName = "Q3";
}
