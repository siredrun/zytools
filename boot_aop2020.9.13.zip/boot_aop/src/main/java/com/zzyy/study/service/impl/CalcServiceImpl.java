package com.zzyy.study.service.impl;


import com.zzyy.study.service.CalcService;
import org.springframework.stereotype.Service;

/**
 * @auther zzyy
 * @create 2020-09-10 21:23
 */
@Service
public class CalcServiceImpl implements CalcService
{
    @Override
    public int div(int x, int y)
    {
        int ret = x / y;

        System.out.println("\t"+"CalcServiceImpl ...... div start invoke"+"\t"+"我们的运算结果是: "+ret);

        return ret;
    }
}
