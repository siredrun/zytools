package com.zzyy.study.service;

/**
 * @auther zzyy
 * @create 2020-09-10 21:23
 */
public interface CalcService
{
    public int div(int x, int y);
}
