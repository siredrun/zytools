package com.zzyy.study.circulardepend;

/**
 * @auther zzyy
 * @create 2020-09-12 13:23
 */
public class ClientCode
{
    public static void main(String[] args)
    {
        A a = new A();
        B b = new B();

        b.setA(a);
        a.setB(b);
    }
}
