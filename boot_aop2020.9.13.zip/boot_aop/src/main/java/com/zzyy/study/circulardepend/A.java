package com.zzyy.study.circulardepend;

/**
 * @auther zzyy
 * @create 2020-09-12 13:22
 */
public class A
{
    private B b;

    public B getB()
    {
        return b;
    }

    public void setB(B b)
    {
        this.b = b;
    }

    public A()
    {
        System.out.println("---A created success");
    }
}
