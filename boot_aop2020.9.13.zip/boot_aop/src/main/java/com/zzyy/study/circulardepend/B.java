package com.zzyy.study.circulardepend;

import cn.hutool.core.util.IdUtil;

/**
 * @auther zzyy
 * @create 2020-09-12 13:22
 */
public class B
{
    private A a;

    public A getA()
    {
        return a;
    }

    public void setA(A a)
    {
        this.a = a;
    }

    public B()
    {
        System.out.println("---B created success");
    }
}
