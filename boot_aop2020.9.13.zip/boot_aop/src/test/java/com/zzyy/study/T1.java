package com.zzyy.study;

import com.zzyy.study.entities.Car;
import com.zzyy.study.service.CalcService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.AnnotatedBeanDefinition;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringBootVersion;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.core.SpringVersion;
import org.springframework.test.context.junit4.SpringRunner;


/**
 * @auther zzyy
 * @create 2020-09-10 22:50
 */
@SpringBootTest
public class T1
{
    @Autowired
    private CalcService service;

    @Test
    public void testSpringVersion()
    {
        System.out.println(SpringVersion.getVersion());
        System.out.println(SpringBootVersion.getVersion());
    }

    @Test
    public void testAop2()
    {
        System.out.println("当前spring版本："+SpringVersion.getVersion()+"\t"+"----当前springboot版本："+SpringBootVersion.getVersion());
        System.out.println();
        int result = service.div(10, 2);

        System.out.println();


        System.out.println(service);
        System.out.println(service.getClass());

    }
}
