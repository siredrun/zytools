package com.zzyy.study.day628;

import java.util.concurrent.*;

/**
 * @auther zzyy
 * @create 2020-06-28 18:32
 */
public class CompletableFutureDemo01
{
    public static void main(String[] args)
    {
        CompletableFuture<String> future = CompletableFuture.supplyAsync(() -> {
            try { TimeUnit.SECONDS.sleep(2); } catch (InterruptedException e) { e.printStackTrace(); }
            return "abc";
        }).whenComplete((v,e) -> {
            if (e == null) {
                System.out.println("*****v: "+v);
            }
        }).exceptionally(e -> {
            e.printStackTrace();
            return null;
        });

        System.out.println("-----main主线程结束");

        System.out.println(future.join());


        //主线程不要立刻结束，否则CompletableFuture默认使用的线程池会立刻关闭:暂停3秒钟线程
        try { TimeUnit.SECONDS.sleep(4); } catch (InterruptedException e) { e.printStackTrace(); }


    }
}
