package com.zzyy.study.day628;

import lombok.Getter;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

/**
 * @auther zzyy
 * @create 2020-06-28 21:21
 */
public class CompletableFutureDemo02
{
    static List<NetMall> list = Arrays.asList(
            new NetMall("jd"),
            new NetMall("pdd"),
            new NetMall("tmall"),
            new NetMall("dd"),
            new NetMall("aa"),
            new NetMall("bb")
    );

    //异步回调威力

    // List<String> = "mysql in pdd price is ???","mysql in jd price is ???"

    /**
     * 同步的演示。。。
     * @param list
     * @param productName
     * @return
     */
    public static List<String> findPriceSync(List<NetMall> list,String productName)
    {
        return list.stream().map(netMall -> String.format(productName + " in %s price is %.2f", netMall.getMallName(), netMall.getPriceByProductName(productName))).collect(Collectors.toList());
    }

    /**
     * 异步的演示。。。
     * @param list
     * @param productName
     * @return
     */
    public static List<String> findPriceASync(List<NetMall> list,String productName)
    {
        return list.stream().
                map(netMall -> CompletableFuture.supplyAsync(
                    () -> String.format(productName + " in %s price is %.2f",
                            netMall.getMallName(),
                            netMall.getPriceByProductName(productName))))
                .collect(Collectors.toList())
            .stream().map(CompletableFuture::join).collect(Collectors.toList());
    }


    public static void main(String[] args)
    {
        long startTime = System.currentTimeMillis();
        List<String> list1 = findPriceSync(list, "mysql");
        for (String element : list1) {
            System.out.println(element);
        }
        long endTime = System.currentTimeMillis();
        System.out.println("----costTime: "+(endTime - startTime) +" 毫秒");

        System.out.println();
        System.out.println();
        System.out.println();

        long startTime2 = System.currentTimeMillis();
        List<String> list2 = findPriceASync(list, "mysql");
        for (String element : list2) {
            System.out.println(element);
        }
        long endTime2 = System.currentTimeMillis();
        System.out.println("----costTime: "+(endTime2 - startTime2) +" 毫秒");
    }
}


class NetMall //内部的其它兄弟部门的系统，不可能为你修改了，公用接口。但是你的leader要求你接口优化，走进多少秒的响应时间。
{
    @Getter
    private String mallName;

    public NetMall(String mallName)
    {
        this.mallName = mallName;
    }

    public double getPriceByProductName(String productName)
    {
        //存在大促、活动、VIP业务，涉及打折
        return calcPrice(productName);
    }

    private double calcPrice(String productName)
    {
        try { TimeUnit.SECONDS.sleep(1); } catch (InterruptedException e) { e.printStackTrace(); }
        return ThreadLocalRandom.current().nextDouble() * 10 +  "a".charAt(0);
    }
}