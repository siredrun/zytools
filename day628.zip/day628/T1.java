package com.zzyy.study.day628;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.FutureTask;
import java.util.concurrent.TimeUnit;

/**
 * @auther zzyy
 * @create 2020-06-28 10:07
 */
public class T1
{
    public static void main(String[] args) throws ExecutionException, InterruptedException
    {
        FutureTask<String> futureTask = new FutureTask<>(() -> {
            try { TimeUnit.SECONDS.sleep(1); } catch (InterruptedException e) { e.printStackTrace(); }
            return "abc";
        });

        Thread t1 = new Thread(futureTask,"t1");
        t1.start();

        System.out.println("------main运行结束");


        //1 会阻塞。。。。。
        //System.out.println(futureTask.get());

        //2 只能不停的去问，哥们，你计算完没？？----》 轮询不停的问，
        while(true)
        {
            if (futureTask.isDone()) {
                System.out.println(futureTask.get());
                break;
            }
        }




    }
}