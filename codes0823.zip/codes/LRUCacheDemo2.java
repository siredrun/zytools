package com.zzyy.study.day823;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * @auther zzyy
 * @create 2020-08-19 14:18
 */
public class LRUCacheDemo2<K,V>
{
    private int cacheSize;
    private LinkedHashMap<Integer,Integer> linkedHashMap;

    public LRUCacheDemo2(int cacheSize)
    {
        this.cacheSize = cacheSize;
        linkedHashMap = new LinkedHashMap<Integer,Integer>(cacheSize,0.75f,false){
            @Override
            protected boolean removeEldestEntry(Map.Entry eldest)
            {
                return linkedHashMap.size() > cacheSize;
            }
        };
    }

    public void put(Integer key,Integer value)
    {
        linkedHashMap.put(key,value);
    }

    public int get(Integer key)
    {
        return linkedHashMap.getOrDefault(key,-1);
    }

    public static void main(String[] args)
    {
        LRUCacheDemo2<Integer,Integer> lruCache = new LRUCacheDemo2<>(3);

        lruCache.put(1,1);
        lruCache.put(2,1);
        lruCache.put(3,1);
        System.out.println(lruCache.linkedHashMap);

        lruCache.put(4,1);
        System.out.println(lruCache.linkedHashMap);

        lruCache.put(3,1);
        System.out.println(lruCache.linkedHashMap);
        lruCache.get(3);
        System.out.println(lruCache.linkedHashMap);
        lruCache.put(5,1);
        System.out.println(lruCache.linkedHashMap);

    }
}