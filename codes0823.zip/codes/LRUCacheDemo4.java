package com.zzyy.study.day823;

import java.util.HashMap;
import java.util.Map;

/**
 * @auther zzyy
 * @create 2020-08-19 14:42
 */
public class LRUCacheDemo4<K,V>
{
    private int size;

    private Map<K, Node> map;

    private Node head;

    private Node tail;

    public LRUCacheDemo4(int size) {
        this.size = size;
        this.map = new HashMap<>();
        this.head = null;
        this.tail = null;
    }

    public void put(K key, V value) {
        if (map.containsKey(key)) {
            Node node = map.get(key);
            node.value = value;
            moveToTail(node);
        } else {
            Node node = new Node(key, value);
            map.put(key, node);
            addToTail(node);

            if (map.size() > size) {
                Node oldHead = removeHead();
                map.remove(oldHead.key);
            }
        }
    }

    private Node removeHead() {
        if (null == head) {
            return null;
        }
        Node node = head;
        System.out.println("最近最少使用的key=" + node.key);
        if (head == tail) {
            head = null;
            tail = null;
        } else {
            head = head.next;
            head.pre = null;
        }

        return node;
    }

    private void addToTail(Node node) {
        if (head == null) {
            head = node;
            tail = node;
        } else {
            tail.next = node;
            node.pre = tail;
            node.next = null;
            tail = node;
        }

    }

    private void moveToTail(Node node) {
        if (node == null || node == tail) {
            return;
        }

        if (node == head) {
            head = head.next;
            head.pre = null;
        } else {
            node.pre.next = node.next;
            node.next.pre = node.pre;
        }

        tail.next = node;
        node.pre = tail;
        node.next = null;
        tail = node;
    }

    public V get(K key) {
        if (map.containsKey(key)) {
            Node node = map.get(key);
            moveToTail(node);
            return node.value;
        } else {
            return null;
        }
    }

    public String toString() {
        if (head == null) {
            return null;
        }

        StringBuilder builder = new StringBuilder();
        builder.append("{");
        Node node = head;
        while (node != null) {
            builder.append(node.key)
                    .append("=")
                    .append(node.value)
                    .append(",");

            node = node.next;
        }

        return builder.substring(0, builder.length() - 1) + "}";
    }

    private class Node {
        private Node pre;

        private Node next;

        private K key;

        private V value;

        public Node(K key, V value) {
            this.key = key;
            this.value = value;
            this.pre = null;
            this.next = null;
        }
    }

    public static void main(String[] args)
    {
        LRUCacheDemo4<Integer,Integer> lruCache = new LRUCacheDemo4<>(3);

        lruCache.put(1,1);
        lruCache.put(2,1);
        lruCache.put(3,1);
        System.out.println(lruCache.map.keySet());

        lruCache.put(4,1);
        System.out.println(lruCache.map.keySet());

        lruCache.put(3,21);
        System.out.println(lruCache.map.keySet());
        lruCache.put(3,22);
        System.out.println(lruCache.map.keySet());
        lruCache.put(5,1);
        System.out.println(lruCache.map.keySet());
    }
}