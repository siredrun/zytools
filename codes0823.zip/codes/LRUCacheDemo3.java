package com.zzyy.study.day823;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/**
 * @auther zzyy
 * @create 2020-08-19 17:30
 */
public class LRUCacheDemo3<K,V>
{
    //凡是链表节点必须有前后
    class Node<K,V>
    {
        K key;
        V value;
        Node<K,V> prev;
        Node<K,V> next;
        //1 spring和写基础框架的套路，必须要有【构造注入】完成数据初始化
        // 1.1 必须要有一个空参的构造方法
        public Node()
        {
            this.prev = this.next = null;
        }
        // 1.2 必须要有全参构造注入函数
        public Node(K key, V value)
        {
            this.key = key;
            this.value = value;
            this.prev = this.next = null;
        }
    }

    //凡是存放node节点的链表必须有头尾head/tail;
    class DoubleLinkedList<K,V>
    {
        Node<K,V> head;
        Node<K,V> tail;

        //1 无惨必须要有【构造注入】完成数据初始化
        public DoubleLinkedList()
        {
            head = new Node<>();
            tail = new Node<>();
            head.next = tail;
            tail.prev = head;
        }
        //=============以下是链表的实际业务方法了。
        //2 常用的添加到头
        public void addHead(Node<K,V> node)
        {
            node.next = head.next;
            node.prev = head;
            head.next.prev = node;
            head.next = node;
        }
        //3 删除节点
        public void removeNode(Node<K,V> node)
        {
            node.prev.next = node.next;
            node.next.prev = node.prev;
            node.next = null;
            node.prev = null;
        }
        //4 获得最后一个，干掉的
        public Node getLast()
        {
            return tail.prev;
        }
    }

    private int cacheSize;//缓存坑位 3个
    Map<Integer,Node<Integer,Integer>> map; //hash负责定位查找，一次性获得链表里面的node（k，v）
    DoubleLinkedList<Integer,Integer> doubleLinkedList;
    Lock lock = new ReentrantLock();

    // 无惨必须要有【构造注入】完成数据初始化
    public LRUCacheDemo3(int cacheSize)
    {
        this.cacheSize = cacheSize;//传入缓存的坑位数字
        map = new ConcurrentHashMap<>();
        doubleLinkedList = new DoubleLinkedList();
    }

    // 读
    public int get(Integer key)
    {
        if(!map.containsKey(key))
        {
            return -1;
        }
        //链表中的key(数据)又被最近使用了一次,将它先从双向链表删除 ----》 移动到我们的定义的开头（最近使用过的）
        Node<Integer, Integer> node = map.get(key);
        doubleLinkedList.removeNode(node);
        doubleLinkedList.addHead(node);

        return node.value;
    }
    // 写
    public void put(Integer key,Integer value)
    {
        //缓存已有----更新 update---(数据)又被最近使用了一次
        if (map.containsKey(key))
        {
            Node<Integer, Integer> node = map.get(key);
            node.value = value;
            map.put(key,node);
            doubleLinkedList.removeNode(node);
            doubleLinkedList.addHead(node);
        }else{
            //新增前要判断坑位是否已近满了
            //坑位满了
            if(map.size() == cacheSize)
            {
                Node lastNode = doubleLinkedList.getLast();
                map.remove(lastNode.key);
                doubleLinkedList.removeNode(lastNode);
            }
            //坑位没有满，新增
            Node<Integer, Integer> newNode = new Node<>(key, value);
            map.put(key,newNode);
            doubleLinkedList.addHead(newNode);
        }
    }

    public static void main(String[] args)
    {
        LRUCacheDemo3<Integer,Integer> lruCache = new LRUCacheDemo3(3);

        lruCache.put(1,1);
        lruCache.put(2,1);
        lruCache.put(3,1);
        System.out.println(lruCache.map.keySet());

        lruCache.put(4,1);
        System.out.println(lruCache.map.keySet());

        lruCache.put(3,1);
        System.out.println(lruCache.map.keySet());
        lruCache.get(3);
        System.out.println(lruCache.map.keySet());
        lruCache.put(5,1);
        System.out.println(lruCache.map.keySet());


    }
}

