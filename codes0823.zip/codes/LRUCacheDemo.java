package com.zzyy.study.day823;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * @auther zzyy
 * @create 2020-08-19 14:14
 */
public class LRUCacheDemo<K,V> extends LinkedHashMap<K,V>
{
    private int cacheSize;

    public LRUCacheDemo(int cacheSize)
    {
        super(cacheSize,0.75F,false);
        this.cacheSize = cacheSize;
    }

    @Override
    protected boolean removeEldestEntry(Map.Entry<K, V> eldest)
    {
        return super.size() > cacheSize;
    }

    public static void main(String[] args)
    {
        LRUCacheDemo lruCache = new LRUCacheDemo(3);

        lruCache.put(1,1);
        lruCache.put(2,1);
        lruCache.put(3,1);
        System.out.println(lruCache.keySet());

        lruCache.put(4,1);
        System.out.println(lruCache.keySet());

        lruCache.put(3,1);
        System.out.println(lruCache.keySet());
        lruCache.get(3);
        System.out.println(lruCache.keySet());
        lruCache.put(5,1);
        System.out.println(lruCache.keySet());

    }
}