package com.zzyy.study.day524;


import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

class SpinLock
{
    AtomicReference<Thread> atomicReference = new AtomicReference();

    public void myLock()
    {
        Thread currentThread = Thread.currentThread();
        System.out.println(Thread.currentThread().getName()+"\t"+"come in");
        while(!atomicReference.compareAndSet(null,currentThread))
        {
            //暂停毫秒
            try { TimeUnit.MILLISECONDS.sleep(500); } catch (InterruptedException e) { e.printStackTrace(); }
            System.out.println(Thread.currentThread().getName()+"\t 排队等待中......");
        }
        System.out.println(Thread.currentThread().getName()+"\t"+"抢占成功");
    }

    public void myUnlock()
    {
        Thread currentThread = Thread.currentThread();
        atomicReference.compareAndSet(currentThread,null);
        System.out.println(Thread.currentThread().getName()+"\t"+"释放成功");
    }
}
/**
 * @auther zzyy
 * @create 2020-05-21 15:19
 * 题目：实现一个自旋锁
 * 自旋锁好处：循环比较获取没有类似wait的阻塞。
 *
 * 通过CAS操作完成自旋锁，A线程先进来调用myLock方法自己持有锁5秒钟，B随后进来后发现
 * 当前有线程持有锁，不是null，所以只能通过自旋等待，直到A释放锁后B随后抢到。
 */
public class SpinLockDemo
{
    public static void main(String[] args)
    {
        SpinLock spinLock = new SpinLock();

        new Thread(() -> {
            spinLock.myLock();
            //暂停几秒钟线程
            try { TimeUnit.SECONDS.sleep(5); } catch (InterruptedException e) { e.printStackTrace(); }
            spinLock.myUnlock();
        },"t1").start();

        new Thread(() -> {
            spinLock.myLock();
            spinLock.myUnlock();
        },"t2").start();


    }
}

