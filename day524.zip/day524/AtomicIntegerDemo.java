package com.zzyy.study.day524;

import java.util.concurrent.atomic.AtomicInteger;

/**
 * @auther zzyy
 * @create 2020-05-24 15:05
 */
public class AtomicIntegerDemo
{
    public static void main(String[] args) throws InterruptedException
    {
        AtomicInteger atomicInteger = new AtomicInteger();
        atomicInteger.incrementAndGet();
        atomicInteger.getAndIncrement();
    }
}
