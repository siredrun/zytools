package com.zzyy.study.day524;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
class Order
{
    private Integer id;
    private String orderName;
}
/**
 * @auther zzyy
 * @create 2020-05-24 17:59
 */
public class AtomicReferenceDemo
{
    public static void main(String[] args)
    {


    }
}
