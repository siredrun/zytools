package com.zzyy.study.day524;

import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicMarkableReference;
import java.util.concurrent.atomic.AtomicStampedReference;

/**
 * @auther zzyy
 * @create 2020-05-24 15:07
 */
public class ABADemo
{
    static AtomicInteger atomicInteger = new AtomicInteger(100);
    static AtomicStampedReference<Integer> atomicStampedReference = new AtomicStampedReference<>(100,1);
    static AtomicMarkableReference<Integer> atomicMarkableReference = new AtomicMarkableReference<>(100,false);

    public static void main(String[] args)
    {
        /*new Thread(() -> {
            atomicInteger.compareAndSet(100,101);
            atomicInteger.compareAndSet(101,100);
        },"t1").start();

        //暂停几秒钟线程
        try { TimeUnit.SECONDS.sleep(1); } catch (InterruptedException e) { e.printStackTrace(); }

        new Thread(() -> {
            atomicInteger.compareAndSet(100,2020);
        },"t2").start();
        System.out.println(atomicInteger.get());*/

        //System.out.println("============AtomicStampedReference 解决ABA问题，没变动一次增加一个版本号，默认都是加1====");
        /*new Thread(() -> {
            System.out.println("t3线程"+"\t 1次版本号： "+atomicStampedReference.getStamp());
            //t3暂停200毫秒,让后续的t4线程获得同样的版本号，方便演示
            try { TimeUnit.MILLISECONDS.sleep(200); } catch (InterruptedException e) { e.printStackTrace(); }
            atomicStampedReference.compareAndSet(100,101,atomicStampedReference.getStamp(),atomicStampedReference.getStamp()+1);
            System.out.println("t3线程"+"\t 2次版本号： "+atomicStampedReference.getStamp());
            atomicStampedReference.compareAndSet(101,100,atomicStampedReference.getStamp(),atomicStampedReference.getStamp()+1);
            System.out.println("t3线程"+"\t 3次版本号： "+atomicStampedReference.getStamp());
        },"t3").start();

        new Thread(() -> {
            int stamp = atomicStampedReference.getStamp();
            System.out.println("t4线程"+"\t 1次版本号： "+stamp);
            //暂停几秒钟线程
            try { TimeUnit.SECONDS.sleep(2); } catch (InterruptedException e) { e.printStackTrace(); }
            boolean b = atomicStampedReference.compareAndSet(100, 2020, stamp, stamp + 1);
            System.out.println(b+"\t"+atomicStampedReference.getStamp()+"\t"+atomicStampedReference.getReference());
        },"t4").start();*/

        System.out.println("============AtomicMarkableReference 无法解决ABA问题，解决标识是否被修改过====");
        new Thread(() -> {
            System.out.println("t5线程"+"\t 1次版本号： "+atomicMarkableReference.isMarked());
            //t3暂停200毫秒,让后续的t4线程获得同样的版本号，方便演示
            try { TimeUnit.MILLISECONDS.sleep(200); } catch (InterruptedException e) { e.printStackTrace(); }
            atomicMarkableReference.compareAndSet(100,101,atomicMarkableReference.isMarked(),!atomicMarkableReference.isMarked());
            System.out.println("t5线程"+"\t 2次版本号： "+atomicMarkableReference.isMarked());
            atomicMarkableReference.compareAndSet(101,100,atomicMarkableReference.isMarked(),!atomicMarkableReference.isMarked());
            System.out.println("t5线程"+"\t 3次版本号： "+atomicMarkableReference.isMarked());
        },"t5").start();

        new Thread(() -> {
            System.out.println("t6线程"+"\t 1次版本号： "+atomicMarkableReference.isMarked());
            //t3暂停200毫秒,让后续的t4线程获得同样的版本号，方便演示
            try { TimeUnit.MILLISECONDS.sleep(200); } catch (InterruptedException e) { e.printStackTrace(); }
            atomicMarkableReference.compareAndSet(100,2020,atomicMarkableReference.isMarked(),!atomicMarkableReference.isMarked());
            System.out.println("************"+atomicMarkableReference.isMarked()+"\t"+atomicMarkableReference.getReference());
        },"t6").start();



    }
}