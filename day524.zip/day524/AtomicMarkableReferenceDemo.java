package com.zzyy.study.day524;

import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicMarkableReference;

/**
 * @auther zzyy
 * @create 2020-05-21 15:31
 */
public class AtomicMarkableReferenceDemo
{
    static AtomicMarkableReference<Integer> atMarkRef = new AtomicMarkableReference<Integer>(100,false);

    public static void main(String[] args)
    {
        new Thread(() -> {
            boolean mark=atMarkRef.isMarked();
            System.out.println("t5 mark:"+mark);
            //更新为200
            System.out.println("t5 result:"+atMarkRef.compareAndSet(atMarkRef.getReference(), 200,mark,!mark));
        },"t5").start();

        new Thread(() -> {
            System.out.println();
            boolean mark2=atMarkRef.isMarked();
            System.out.println("t6 mark2:"+mark2);
            System.out.println("t6 result:"+atMarkRef.compareAndSet(atMarkRef.getReference(), 100,mark2,!mark2));
        },"t6").start();

        new Thread(() -> {
            System.out.println();
            boolean mark=atMarkRef.isMarked();
            System.out.println("sleep 前 t7 mark:"+mark);
            //暂停几秒钟线程
            try { TimeUnit.SECONDS.sleep(1L); } catch (InterruptedException e) { e.printStackTrace(); }
            boolean flag=atMarkRef.compareAndSet(100,500,mark,!mark);
            System.out.println("flag:"+flag+"\t"+",newValue:"+atMarkRef.getReference());
        },"t7").start();
    }
}/**
 * 输出结果:
 t5 mark:false
 t5 result:true

 t6 mark2:true
 t6 result:true    --->atMarkRef.compareAndSet(atMarkRef.getReference(), 100,mark2,!mark2)返回true的话，这个就说明了t6干了ABA问题


 sleep 前 t7 mark:false
 flag:true	,newValue:500 ---->成功了.....说明还是发生ABA问题

 ==================================


 * 输出结果:
 t5 mark:false

 t6 mark2:false
 t6 result:false   ----> atMarkRef.compareAndSet(atMarkRef.getReference(), 100,mark2,!mark2)返回false的话，没有ABA
 t5 result:true

 sleep 前 t7 mark:true
 flag:false	,newValue:200
 */
