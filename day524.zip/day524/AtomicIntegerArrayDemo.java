package com.zzyy.study.day524;

import java.util.concurrent.atomic.AtomicIntegerArray;

/**
 * @auther zzyy
 * @create 2020-05-21 14:51
 */
public class AtomicIntegerArrayDemo
{
    public static void main(String[] args)
    {
        //AtomicIntegerArray atomicIntegerArray1 = new AtomicIntegerArray(new int[5]);
        AtomicIntegerArray atomicIntegerArray1 = new AtomicIntegerArray(5);
        //AtomicIntegerArray atomicIntegerArray1 = new AtomicIntegerArray(new int[]{1,2,3,4,5});

        /*atomicIntegerArray1.set(0,11);
        atomicIntegerArray1.set(1,12);
        atomicIntegerArray1.set(2,13);
        atomicIntegerArray1.set(3,14);
        atomicIntegerArray1.set(4,15);*/

        for (int i = 0; i < atomicIntegerArray1.length(); i++) {
            System.out.println(atomicIntegerArray1.get(i));
        }

        System.out.println();
        System.out.println(atomicIntegerArray1.get(1));
        atomicIntegerArray1.getAndSet(1,1111);
        System.out.println(atomicIntegerArray1.get(1));
    }
}











/*AtomicIntegerArray atomicIntegerArray1 = new AtomicIntegerArray(new int[5]);
        //AtomicIntegerArray atomicIntegerArray1 = new AtomicIntegerArray(5);
        //AtomicIntegerArray atomicIntegerArray1 = new AtomicIntegerArray(new int[]{1,2,3,4,5});

        atomicIntegerArray1.set(0,11);
        atomicIntegerArray1.set(1,12);
        atomicIntegerArray1.set(2,13);
        atomicIntegerArray1.set(3,14);
        atomicIntegerArray1.set(4,15);

        for (int i = 0; i < atomicIntegerArray1.length(); i++) {
            System.out.println(atomicIntegerArray1.get(i));
        }

        System.out.println();
        System.out.println(atomicIntegerArray1.get(1));
        atomicIntegerArray1.getAndSet(1,1111);
        System.out.println(atomicIntegerArray1.get(1));*/