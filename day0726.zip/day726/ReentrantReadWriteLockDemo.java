package com.zzyy.study.day726;


import java.util.concurrent.locks.ReentrantReadWriteLock;

class MyResource
{

}


/**
 * @auther zzyy
 * @create 2020-07-26 9:49
 */
public class ReentrantReadWriteLockDemo
{
    public static void main(String[] args)
    {
        ReentrantReadWriteLock rwLock = new ReentrantReadWriteLock();

        //1 ReentrantReadWriteLock锁降级：遵循获取写锁→再获取读锁→再释放写锁的次序，写锁能够降级成为读锁。

        // 备注：必须ReentrantReadWriteLock符合锁降级策略
        // 如果read操作没有全部结束，写锁只能等待，无法介入。

        //error,违背锁降级策略
        //读锁没有全部over的话，写锁不可以介入
        rwLock.readLock().lock();
        System.out.println("-----读锁");
        //rwLock.readLock().unlock();

        rwLock.writeLock().lock();
        System.out.println("-----写锁");




        //right
        /*rwLock.writeLock().lock();
        System.out.println("-----写锁");

        rwLock.readLock().lock();
        System.out.println("-----读锁");*/


    }
}












