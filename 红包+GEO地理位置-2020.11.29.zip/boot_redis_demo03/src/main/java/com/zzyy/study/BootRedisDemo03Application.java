package com.zzyy.study;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootRedisDemo03Application
{

    public static void main(String[] args)
    {
        SpringApplication.run(BootRedisDemo03Application.class, args);
    }

}
