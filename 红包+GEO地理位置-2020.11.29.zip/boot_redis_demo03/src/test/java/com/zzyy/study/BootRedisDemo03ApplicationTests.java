package com.zzyy.study;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BootRedisDemo03ApplicationTests
{

    @Test
    void contextLoads()
    {
    }

}
