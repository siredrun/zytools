package com.zzyy.study.entities;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @auther zzyy
 * @create 2020-11-07 16:43
 */
@AllArgsConstructor
@Data
@NoArgsConstructor
public class PhoneList
{
    private String IDNumber;
    private String  spName;
}
