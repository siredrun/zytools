package com.zzyy.study;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BloomfilterDemoApplication
{

    public static void main(String[] args)
    {
        SpringApplication.run(BloomfilterDemoApplication.class, args);
    }

}
