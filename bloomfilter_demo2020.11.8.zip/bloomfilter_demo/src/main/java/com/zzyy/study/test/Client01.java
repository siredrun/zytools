package com.zzyy.study.test;

/**
 * @auther zzyy
 * @create 2020-11-08 19:37
 */
public class Client01
{
    public static void main(String[] args)
    {
        System.out.println("Aa".hashCode());
        System.out.println("BB".hashCode());

        System.out.println("柳柴".hashCode());
        System.out.println("柴柕".hashCode());

    }
}
